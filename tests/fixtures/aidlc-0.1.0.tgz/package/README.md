# AIDLC

A development lifecycle for coding agents, evolving from a repository template into an installable CLI and shared Core. This bootstrap is version `0.1.0` and supports the default workflow with Codex definitions.

## Build and install locally

Contributors use Bun 1.4 or later to build and test. The installed package uses Node.js 22 or later and has no runtime npm dependencies. This change was exercised on Windows with Node 24.11.1; other supported Node versions still need CI coverage.

```powershell
bun install
bun run build
bun test
npm pack
npm install --global ./aidlc-0.1.0.tgz
```

The package remains private while the bootstrap is under review. `npm pack` builds a local tarball; it does not publish a release. Do not use an unverified registry package with the same name.

From a consumer project, run:

```powershell
aidlc init --preset default --harness codex --governance standard
aidlc doctor
aidlc config
```

Or target an explicit directory:

```powershell
aidlc --cwd "C:\projects\my game" init
```

`init` targets exactly the current directory or `--cwd`, not an inferred parent repository. Governance defaults to `strict`. Supported governance choices are `strict`, `standard` and `autonomous`; only `default` and `codex` are supported as preset and harness in this bootstrap.

## Ownership and diagnostics

Initialization preflights conflicts, preserves existing `AIDLC.md`, appends a delimited AIDLC block to `AGENTS.md`, and refuses to overwrite preexisting generated files or configuration. A valid repeated `init` makes no file changes. An existing AIDLC repository without a manifest requires future explicit adoption; it is not silently converted.

Existing `AGENTS.md` must be valid UTF-8, with an optional UTF-8 BOM. Initialization checks its encoding before writing project content and appends the managed block without rewriting the original bytes. UTF-16, invalid UTF-8 and NUL-containing instructions are refused with a conversion message; the original file remains untouched.

`.aidlc/install.json` records installation schema, framework/component versions, managed paths, content hashes and user-owned state. Configuration schema version and installed framework version are separate. Configuration, intents, context, observations and external skills are user-owned; generated resources are managed. User edits outside the delimited `AGENTS.md` block do not count as managed drift.

`doctor` is read-only. It reports missing files, unsupported schema/components, malformed configuration and modified managed content. Managed drift is an error to resolve before a future update; this bootstrap does not repair it automatically. A legacy project gets a no-manifest warning. User configuration changes that remain valid are allowed; `init` does not change an existing project's governance.

Initialization uses a project lock. On a preflight conflict, no project content is changed. A filesystem failure after writes begin may leave a partial installation; the error lists created files. Inspect them before retrying. Interrupted-init recovery, legacy adoption, update, rollback and schema migrations belong to the next intent.

## Commands and compatibility

New commands: `init`, `config`, `doctor`, `--version`, `--help`. Existing `setup`, `check-setup`, `new`, `status`, `list`, `next`, `validate`, `branch`, `transition` and `close` remain available. The source compatibility entry point is still `bun scripts/aidlc.ts` and existing package scripts are preserved.

Legacy command dispatch validates configuration, state and installation-manifest compatibility before any command can write files or create directories. Recognized legacy projects without a manifest remain supported. Only `setup` can start without configuration; commands such as `new` require initialized configuration. Unsupported schema or component versions must be handled by a compatible CLI or explicit migration.

Core configuration parsing, intent validation, installation and diagnostics accept an explicit project root and return data. Legacy lifecycle command dispatch remains at the CLI boundary; its later extraction and modern intent subcommands are separate work.

## Models

New installations generate these Codex definitions:

| Role | Model | Reasoning |
|---|---|---|
| Orchestrator and Reader | `gpt-6-luna` | `high` |
| Planner | `gpt-6.2-sol` | `high` |
| Builder and Tester | `gpt-6.2-sol` | `medium` |
| Routine Reviewer | `gpt-6.2-sol` | `high` |
| Documenter | `gpt-6-luna` | `high` |

The workflow reserves `gpt-6.2-astra` at `high` for high-risk or unresolved review questions. It does not generate an always-running specialist agent or automatically switch models. Existing definitions in the framework checkout are not modified by package initialization tests. Generated files express intended configuration, not evidence that a particular model executed work. Runtime dispatch, model overrides and availability checks belong to the adapter intent.

## Next milestones

The roadmap lives at `docs/aidlc-cli-roadmap.md` in the source repository. Safe updates/migrations are next, followed by configurable lifecycle presets, adapters, Task Observer, Unity Mini, context/resume and multi-project inventory. Unity skills will be supplied separately by the user. No game project or global skill installation is modified by this bootstrap.
